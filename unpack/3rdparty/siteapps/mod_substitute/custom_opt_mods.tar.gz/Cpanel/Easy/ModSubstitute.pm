package Cpanel::Easy::ModSubstitute;

our $easyconfig = {
    'version' => '$Rev: 2.2.26 $',
    'name'    => 'Mod Substitute',
    'note'       => 'Required for SiteApps Plugin',
    'url'     => 'http://httpd.apache.org/docs/2.2/mod/mod_substitute.html',
    'desc'       => 'mod_substitute allows for the replacement of content into text/html Apache responses.',
    'verify_off' => 'If you turn off mod_substitute, SiteApps plugin may not work properly. Are you sure you wish to turn off mod_substitute?',
    'src_cd2' => 'mod_substitute',
    'hastargz' => 1,
    'skip'       => 0,
    'step'    => {
        '0' => {
            'name'    => 'Compiling and installing',
            'command' => sub {
                my ($self) = @_;

                my ($rc, @msg) = $self->run_system_cmd_returnable( [ $self->_get_main_apxs_bin(), qw(-i -c mod_substitute.c)] );
                return ($rc, @msg);
            },            
        },
    },    
};

1;
